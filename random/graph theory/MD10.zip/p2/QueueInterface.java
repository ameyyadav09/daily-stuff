interface QueueInterface {
  public void insert(int value);
  public void delete();
  public boolean isEmpty();
  public void print();
}